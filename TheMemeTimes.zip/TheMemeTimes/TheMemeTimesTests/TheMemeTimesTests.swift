//
//  TheMemeTimesTests.swift
//  TheMemeTimesTests
//
//  Created by Valentina-Gabriela Corcodel on 19.06.2025.
//

import Testing
@testable import TheMemeTimes

struct TheMemeTimesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
