import SwiftUI

struct GenerateButtonView: View {
    let userData: UserData
    let selectedInterests: Set<String>
    @Binding var showMemeGenerator: Bool
    
    var body: some View {
        NavigationLink(
            destination: MemeGeneratorView(userData: UserData(
                name: userData.name,
                age: userData.age,
                interests: selectedInterests,
                location: userData.location
            )),
            isActive: $showMemeGenerator
        ) {
            Button(action: {
                showMemeGenerator = true
            }) {
                HStack {
                    Text("Generate")
                        .font(.system(.headline, design: .rounded))
                    
                    Image(systemName: "sparkles")
                        .font(.system(size: 16, weight: .semibold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(
                    selectedInterests.isEmpty ?
                    Color.gray.opacity(0.3) :
                    Color.black
                )
                .cornerRadius(16)
                .shadow(color: selectedInterests.isEmpty ? .clear : .black.opacity(0.1),
                        radius: 10, x: 0, y: 5)
            }
        }
        .disabled(selectedInterests.isEmpty)
        .padding(.horizontal)
        .padding(.top, 20)
    }
}

#Preview {
    GenerateButtonView(
        userData: UserData(name: "Test User", age: 25, interests: []),
        selectedInterests: ["Memes", "Gaming"],
        showMemeGenerator: .constant(false)
    )
} 