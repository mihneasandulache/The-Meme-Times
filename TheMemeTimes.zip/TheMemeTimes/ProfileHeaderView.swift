import SwiftUI

struct ProfileHeaderView: View {
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "square.stack.3d.up.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .foregroundStyle(.gray.opacity(0.9))
                .padding(.top, 20)
            
            Text("Your Profile")
                .font(.system(size: 28, weight: .medium, design: .rounded))
                .foregroundColor(.primary)
        }
        .padding(.bottom, 10)
    }
}

#Preview {
    ProfileHeaderView()
} 