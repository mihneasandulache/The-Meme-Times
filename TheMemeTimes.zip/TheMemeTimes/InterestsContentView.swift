import SwiftUI

struct InterestsContentView: View {
    @Binding var userData: UserData
    @Binding var selectedInterests: Set<String>
    @Binding var showMemeGenerator: Bool
    @Binding var customInterest: String
    @Binding var isEditingName: Bool
    let addCustomInterest: () -> Void
    let columns: [GridItem]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 32) {
                ProfileHeaderView()
                
                NameSectionView(name: $userData.name, isEditingName: $isEditingName)
                
                InterestsInputView(customInterest: $customInterest, addCustomInterest: addCustomInterest)
                
                CustomInterestsSectionView(selectedInterests: $selectedInterests, columns: columns)
                
                SuggestedInterestsSectionView(selectedInterests: $selectedInterests, columns: columns)
                
                GenerateButtonView(userData: userData, selectedInterests: selectedInterests, showMemeGenerator: $showMemeGenerator)
            }
            .padding(.bottom, 30)
        }
    }
}

#Preview {
    InterestsContentView(
        userData: .constant(UserData(name: "Test User", age: 25, interests: [])),
        selectedInterests: .constant([]),
        showMemeGenerator: .constant(false),
        customInterest: .constant(""),
        isEditingName: .constant(false),
        addCustomInterest: {},
        columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
    )
} 