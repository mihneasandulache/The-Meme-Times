//
//  TheMemeTimesApp.swift
//  TheMemeTimes
//
//  Created by Valentina-Gabriela Corcodel on 19.06.2025.
//

import SwiftUI

@main
struct TheMemeTimesApp: App {
    var body: some Scene {
        WindowGroup {
            LocationPermissionView()
        }
    }
}
