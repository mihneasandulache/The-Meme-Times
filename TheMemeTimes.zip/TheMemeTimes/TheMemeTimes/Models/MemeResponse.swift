import Foundation

struct MemeItem: Identifiable {
    let id = UUID()
    let imageUrl: String
    let authorName: String
    let title: String
    let text: String
    let sourceUrl: String
}

class MemeGenerator: ObservableObject {
    @Published var memeItems: [MemeItem] = []
    
    // Mock image URLs for demonstration
    private let mockImageUrls = [
        "https://source.unsplash.com/random/800x600?meme",
        "https://source.unsplash.com/random/800x600?funny",
        "https://source.unsplash.com/random/800x600?art",
        "https://source.unsplash.com/random/800x600?digital",
        "https://source.unsplash.com/random/800x600?creative",
        "https://source.unsplash.com/random/800x600?humor",
        "https://source.unsplash.com/random/800x600?fun"
    ]
    
    private let mockAuthors = [
        "MemeKing42",
        "LaughMaster",
        "ViralVibe",
        "MemeQueen",
        "JestJedi",
        "HumorHero",
        "GiggleGenius"
    ]
    
    private let mockTitles = [
        "Programming Life",
        "Code Magic",
        "Social Struggles",
        "Gaming Moments",
        "Developer Life",
        "Meeting Reality",
        "Self Perception"
    ]
    
    private let mockTexts = [
        "A hilarious take on the daily struggles of programmers with their feline companions. This meme perfectly captures the moment when your cat decides your keyboard is the perfect spot for a nap, leading to unexpected code contributions.",
        "That magical moment in every developer's life when the code unexpectedly works. The confusion and joy mixed together create a perfect representation of programming reality.",
        "An accurate portrayal of trying to explain internet culture to friends who aren't as invested in the meme world. The disconnect is real and hilarious.",
        "A gaming-themed meme that resonates with anyone who's been asked about their progress while in the middle of a tough game. The internal vs. external reaction is priceless.",
        "Late-night debugging sessions captured in their full glory. The progression from confidence to confusion to desperation is something every developer can relate to.",
        "The stark contrast between focus levels during work meetings versus free time. This meme hits close to home for anyone who's struggled with maintaining attention in professional settings.",
        "A clever take on self-image versus reality, using popular meme formats to illustrate the often humorous disconnect between how we perceive ourselves and how others see us."
    ]
    
    private let mockSourceUrls = [
        "https://reddit.com/r/ProgrammerHumor/cat-coding",
        "https://reddit.com/r/ProgrammerHumor/it-works",
        "https://reddit.com/r/memes/explaining-memes",
        "https://reddit.com/r/gaming/winning-son",
        "https://reddit.com/r/ProgrammerHumor/debugging-night",
        "https://reddit.com/r/memes/meeting-brain",
        "https://reddit.com/r/memes/self-perception"
    ]
    
    func generateMemes(age: Int, interests: Set<String>) async -> [MemeItem] {
        // Simulate API call delay
        try? await Task.sleep(nanoseconds: 2 * 1_000_000_000) // 2 second delay
        
        // Generate 3 random meme items
        var items: [MemeItem] = []
        var usedIndices = Set<Int>()
        
        // Get the minimum count to ensure we don't go out of bounds
        let maxIndex = min(
            mockTitles.count,
            mockTexts.count,
            mockSourceUrls.count,
            mockImageUrls.count
        ) - 1
        
        // Generate 3 unique random memes or as many as we can
        while items.count < 3 && usedIndices.count <= maxIndex {
            let index = Int.random(in: 0...maxIndex)
            
            // Skip if we've already used this index
            guard !usedIndices.contains(index) else { continue }
            usedIndices.insert(index)
            
            let item = MemeItem(
                imageUrl: mockImageUrls[index],
                authorName: mockAuthors.randomElement() ?? mockAuthors[0],
                title: mockTitles[index],
                text: mockTexts[index],
                sourceUrl: mockSourceUrls[index]
            )
            items.append(item)
        }
        
        return items
    }
} 