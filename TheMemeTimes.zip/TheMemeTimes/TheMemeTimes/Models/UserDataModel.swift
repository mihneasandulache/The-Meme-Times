import Foundation
import CoreLocation

struct UserData: Identifiable {
    var id = UUID()
    var name: String
    var age: Int
    var interests: Set<String>
    var location: Location?
}

struct Location {
    var city: String
    var country: String
}

class UserDataModel: ObservableObject {
    @Published var userData: UserData
    @Published var locationManager = LocationManager()
    
    static let funnyNames = [
        "Meme Lord",
        "Doge Master",
        "Gigachad",
        "Stonks Guy",
        "Pepe Pro",
        "Rick Roller",
        "Sus Imposter",
        "Wholesome 100",
        "Big Chungus",
        "Bonk Master"
    ]
    
    static let availableInterests = [
        "Memes 🎭",
        "Gaming 🎮",
        "Coding 💻",
        "Music 🎵",
        "Art 🎨",
        "Sports 🏃‍♂️",
        "Food 🍕",
        "Travel ✈️",
        "Movies 🎬",
        "Books 📚",
        "Science 🔬",
        "Photography 📸"
    ]
    
    init() {
        self.userData = UserData(
            name: Self.funnyNames.randomElement() ?? "Meme Lord",
            age: 18,
            interests: []
        )
    }
}

class LocationManager: NSObject, ObservableObject {
    private let locationManager = CLLocationManager()
    @Published var location: CLLocation?
    @Published var city: String = ""
    @Published var country: String = ""
    @Published var errorMessage: String?
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func requestLocation() {
        locationManager.requestWhenInUseAuthorization()
    }
    
    func fetchLocationDetails() {
        guard let location = location else { return }
        
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { [weak self] placemarks, error in
            guard let self = self else { return }
            
            if let error = error {
                self.errorMessage = error.localizedDescription
                return
            }
            
            guard let placemark = placemarks?.first else {
                self.errorMessage = "No location found"
                return
            }
            
            DispatchQueue.main.async {
                self.city = placemark.locality ?? "Unknown City"
                self.country = placemark.country ?? "Unknown Country"
            }
        }
    }
}

extension LocationManager: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        self.location = location
        fetchLocationDetails()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        errorMessage = error.localizedDescription
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
        
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.requestLocation()
        case .denied, .restricted:
            errorMessage = "Location access denied"
        case .notDetermined:
            break
        @unknown default:
            break
        }
    }
} 