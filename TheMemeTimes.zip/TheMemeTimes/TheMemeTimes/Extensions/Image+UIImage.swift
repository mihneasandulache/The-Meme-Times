import SwiftUI

extension Image {
    func asUIImage() -> UIImage? {
        let controller = UIHostingController(rootView: self)
        
        // Set the correct size
        controller.view.frame = CGRect(x: 0, y: 0, width: 800, height: 450) // 16:9 aspect ratio
        
        // Ensure the view has been laid out
        controller.view.layoutIfNeeded()
        
        // Create the image
        let renderer = UIGraphicsImageRenderer(size: controller.view.bounds.size)
        return renderer.image { _ in
            controller.view.drawHierarchy(in: controller.view.bounds, afterScreenUpdates: true)
        }
    }
} 