import SwiftUI

struct InterestsEditSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedInterests: Set<String>
    @State private var customInterest: String = ""
    @State private var customInterestsList: [String] = []
    @State private var showInvalidInputAlert = false
    let onSave: () -> Void
    
    let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 32) {
                    // Custom Interest Input
                    customInterestInputSection
                    
                    // Custom Interests Section
                    if !customInterestsList.isEmpty {
                        customInterestsSection
                    }
                    
                    // Suggested Interests
                    suggestedInterestsSection
                }
                .padding(.horizontal)
                .padding(.vertical, 20)
            }
            .background(Color.black.opacity(0.02))
            .navigationTitle("Edit Interests")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        onSave()
                        dismiss()
                    }
                }
            }
        }
        .alert("Invalid Interest", isPresented: $showInvalidInputAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Interest must be at least 2 characters long.")
        }
    }
    
    private var customInterestInputSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("ADD YOUR INTERESTS")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
            
            HStack {
                TextField("Type an interest...", text: $customInterest)
                    .textFieldStyle(ModernTextFieldStyle())
                    .submitLabel(.done)
                    .onSubmit(addCustomInterest)
                
                addInterestButton
            }
        }
    }
    
    private var addInterestButton: some View {
        Button(action: addCustomInterest) {
            Image(systemName: "plus")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(customInterest.isEmpty ? .gray : .black)
                .frame(width: 36, height: 36)
                .background(
                    Circle()
                        .fill(customInterest.isEmpty ? Color.black.opacity(0.05) : Color.white)
                )
        }
        .disabled(customInterest.isEmpty)
    }
    
    private var customInterestsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("YOUR INTERESTS")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
            
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(customInterestsList, id: \.self) { interest in
                    InterestTag(
                        title: interest,
                        isSelected: true,
                        showRemove: true
                    ) {
                        withAnimation(.spring(response: 0.3)) {
                            customInterestsList.removeAll { $0 == interest }
                            selectedInterests.remove(interest)
                        }
                    }
                }
            }
        }
    }
    
    private var suggestedInterestsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("SUGGESTED")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
            
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(UserDataModel.availableInterests, id: \.self) { interest in
                    InterestTag(
                        title: interest,
                        isSelected: selectedInterests.contains(interest)
                    ) {
                        withAnimation(.spring(response: 0.3)) {
                            if selectedInterests.contains(interest) {
                                selectedInterests.remove(interest)
                            } else {
                                selectedInterests.insert(interest)
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func addCustomInterest() {
        let trimmedInterest = customInterest.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedInterest.count >= 2 {
            withAnimation(.spring(response: 0.3)) {
                customInterestsList.append(trimmedInterest)
                selectedInterests.insert(trimmedInterest)
                customInterest = ""
            }
        } else {
            showInvalidInputAlert = true
        }
    }
}

#Preview {
    InterestsEditSheet(
        selectedInterests: .constant(["Memes 🎭", "Gaming 🎮"]),
        onSave: {}
    )
} 