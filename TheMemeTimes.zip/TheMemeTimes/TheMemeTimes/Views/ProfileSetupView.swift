import SwiftUI
import CoreLocation

struct ProfileSetupView: View {
    @ObservedObject var userDataModel: UserDataModel
    @State private var selectedInterests: Set<String> = []
    @State private var showMemeGenerator = false
    @State private var customInterestsList: [String] = []
    @State private var isEditingName = false
    @State private var customInterest: String = ""
    @State private var showInvalidInputAlert = false
    @Environment(\.dismiss) private var dismiss
    
    let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
    
    var body: some View {
        ZStack {
            // Modern gradient background
            LinearGradient(gradient: Gradient(colors: [
                Color.black.opacity(0.05),
                Color.gray.opacity(0.1)
            ]), startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 32) {
                    // Header
                    headerSection
                    
                    // Name Section
                    nameSection
                    
                    // Age Section
                    ageSection
                    
                    // Location Section
                    locationSection
                    
                    // Custom Interest Input
                    customInterestInputSection
                    
                    // Custom Interests Section
                    if !customInterestsList.isEmpty {
                        customInterestsSection
                    }
                    
                    // Suggested Interests
                    suggestedInterestsSection
                    
                    // Generate Button
                    generateButtonSection
                }
                .padding(.bottom, 30)
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarHidden(true)
        .alert("Invalid Interest", isPresented: $showInvalidInputAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Interest must be at least 2 characters long.")
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 8) {
            Image(systemName: "person.crop.circle.badge.plus")
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .foregroundStyle(.gray.opacity(0.9))
                .padding(.top, 20)
            
            Text("Profile Setup")
                .font(.system(size: 28, weight: .medium, design: .rounded))
                .foregroundColor(.primary)
            
            Text("Tell us about yourself")
                .font(.system(size: 16, design: .rounded))
                .foregroundColor(.secondary)
        }
    }
    
    private var nameSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("NAME")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            HStack {
                if isEditingName {
                    TextField("Your name", text: $userDataModel.userData.name)
                        .font(.system(.body, design: .rounded))
                        .textFieldStyle(ModernTextFieldStyle())
                } else {
                    Text(userDataModel.userData.name)
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.primary)
                }
                
                Spacer()
                
                Button(action: {
                    userDataModel.userData.name = UserDataModel.funnyNames.randomElement() ?? "Meme Lord"
                }) {
                    Image(systemName: "dice")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.05))
                        .clipShape(Circle())
                }
                
                Button(action: { isEditingName.toggle() }) {
                    Image(systemName: isEditingName ? "checkmark" : "pencil")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.05))
                        .clipShape(Circle())
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.03), radius: 10, x: 0, y: 5)
            .padding(.horizontal)
        }
    }
    
    private var ageSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("AGE")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            HStack {
                Stepper(
                    value: $userDataModel.userData.age,
                    in: 13...100,
                    step: 1
                ) {
                    Text("\(userDataModel.userData.age) years")
                        .font(.system(.body, design: .rounded))
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.03), radius: 10, x: 0, y: 5)
            .padding(.horizontal)
        }
    }
    
    private var locationSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("LOCATION")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            HStack {
                if let location = userDataModel.userData.location {
                    VStack(alignment: .leading) {
                        Text(location.city)
                            .font(.system(.body, design: .rounded))
                        Text(location.country)
                            .font(.system(.subheadline, design: .rounded))
                            .foregroundColor(.secondary)
                    }
                } else {
                    Text("Detecting location...")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "location.fill")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.03), radius: 10, x: 0, y: 5)
            .padding(.horizontal)
        }
    }
    
    private var customInterestInputSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("ADD YOUR INTERESTS")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            HStack {
                TextField("Type an interest...", text: $customInterest)
                    .textFieldStyle(ModernTextFieldStyle())
                    .submitLabel(.done)
                    .onSubmit(addCustomInterest)
                
                addInterestButton
            }
            .padding(.horizontal)
        }
    }
    
    private var addInterestButton: some View {
        Button(action: addCustomInterest) {
            Image(systemName: "plus")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(customInterest.isEmpty ? .gray : .black)
                .frame(width: 36, height: 36)
                .background(
                    Circle()
                        .fill(customInterest.isEmpty ? Color.black.opacity(0.05) : Color.white)
                )
        }
        .disabled(customInterest.isEmpty)
    }
    
    private var customInterestsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("YOUR INTERESTS")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(customInterestsList, id: \.self) { interest in
                    InterestTag(
                        title: interest,
                        isSelected: true,
                        showRemove: true
                    ) {
                        withAnimation(.spring(response: 0.3)) {
                            customInterestsList.removeAll { $0 == interest }
                            selectedInterests.remove(interest)
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
    
    private var suggestedInterestsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("SUGGESTED")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(UserDataModel.availableInterests, id: \.self) { interest in
                    InterestTag(
                        title: interest,
                        isSelected: selectedInterests.contains(interest)
                    ) {
                        withAnimation(.spring(response: 0.3)) {
                            if selectedInterests.contains(interest) {
                                selectedInterests.remove(interest)
                            } else {
                                selectedInterests.insert(interest)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
    
    private var generateButtonSection: some View {
        Button(action: {
            userDataModel.userData.interests = selectedInterests
            withAnimation {
                showMemeGenerator = true
            }
        }) {
            HStack {
                Text("Generate")
                    .font(.system(.headline, design: .rounded))
                
                Image(systemName: "sparkles")
                    .font(.system(size: 16, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(selectedInterests.isEmpty ? Color.gray.opacity(0.3) : Color.black)
            .cornerRadius(16)
            .shadow(color: selectedInterests.isEmpty ? .clear : .black.opacity(0.1),
                    radius: 10, x: 0, y: 5)
        }
        .disabled(selectedInterests.isEmpty)
        .padding(.horizontal)
        .padding(.top, 20)
        .background(
            NavigationLink(destination: MemeGeneratorView(userData: UserData(
                name: userDataModel.userData.name,
                age: userDataModel.userData.age,
                interests: selectedInterests,
                location: userDataModel.userData.location
            ))
            .navigationBarBackButtonHidden(true),
            isActive: $showMemeGenerator) {
                EmptyView()
            }
        )
    }
    
    private func addCustomInterest() {
        let trimmedInterest = customInterest.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedInterest.count >= 2 {
            withAnimation(.spring(response: 0.3)) {
                customInterestsList.append(trimmedInterest)
                selectedInterests.insert(trimmedInterest)
                customInterest = ""
            }
        } else {
            showInvalidInputAlert = true
        }
    }
}

struct ModernTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.03), radius: 10, x: 0, y: 5)
    }
}

#Preview {
    NavigationView {
        ProfileSetupView(userDataModel: UserDataModel())
    }
} 