import SwiftUI
import CoreLocation

struct LocationPermissionView: View {
    @StateObject private var userDataModel = UserDataModel()
    @State private var showUserInfo = false
    @State private var skipLocation = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Modern gradient background
                LinearGradient(gradient: Gradient(colors: [
                    Color.black.opacity(0.05),
                    Color.gray.opacity(0.1)
                ]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                VStack(spacing: 32) {
                    Spacer()
                    
                    // Icon and Title
                    VStack(spacing: 24) {
                        Image(systemName: "location.circle.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundStyle(.gray.opacity(0.9))
                        
                        Text("Enable Location")
                            .font(.system(size: 28, weight: .medium, design: .rounded))
                            .multilineTextAlignment(.center)
                        
                        Text("Get personalized content based on your location")
                            .font(.system(size: 16, design: .rounded))
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }
                    
                    Spacer()
                    
                    // Location Status
                    if let error = userDataModel.locationManager.errorMessage {
                        Text(error)
                            .font(.system(.subheadline, design: .rounded))
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    if !userDataModel.locationManager.city.isEmpty {
                        VStack(spacing: 8) {
                            Text("Location Found")
                                .font(.system(.headline, design: .rounded))
                                .foregroundColor(.primary)
                            
                            Text("\(userDataModel.locationManager.city), \(userDataModel.locationManager.country)")
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(16)
                        .shadow(color: Color.black.opacity(0.05), radius: 10)
                    }
                    
                    // Buttons
                    VStack(spacing: 16) {
                        Button(action: {
                            userDataModel.locationManager.requestLocation()
                        }) {
                            HStack {
                                Image(systemName: "location.fill")
                                Text("Allow Location Access")
                            }
                            .font(.system(.headline, design: .rounded))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(Color.black)
                            .cornerRadius(16)
                            .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                        }
                        
                        Button(action: {
                            skipLocation = true
                        }) {
                            Text("Skip")
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.bottom, 30)
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
        .onChange(of: userDataModel.locationManager.city) { newCity in
            if !newCity.isEmpty {
                userDataModel.userData.location = Location(
                    city: userDataModel.locationManager.city,
                    country: userDataModel.locationManager.country
                )
                showUserInfo = true
            }
        }
        .onChange(of: skipLocation) { skip in
            if skip {
                showUserInfo = true
            }
        }
        .fullScreenCover(isPresented: $showUserInfo) {
            NavigationView {
                ProfileSetupView(userDataModel: userDataModel)
            }
        }
    }
}

#Preview {
    LocationPermissionView()
} 