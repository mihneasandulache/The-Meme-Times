import SwiftUI

struct MemeGeneratorView: View {
    @State var userData: UserData
    @StateObject private var memeGenerator = MemeGenerator()
    @State private var isLoading = true
    @State private var isRegenerating = false
    @State private var showingInterestsSheet = false
    @State private var selectedInterests: Set<String>
    
    init(userData: UserData) {
        self._userData = State(initialValue: userData)
        self._selectedInterests = State(initialValue: userData.interests)
    }
    
    var body: some View {
        ZStack {
            // Modern gradient background
            LinearGradient(gradient: Gradient(colors: [
                Color.black.opacity(0.05),
                Color.gray.opacity(0.1)
            ]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            if isLoading {
                LoadingView()
            } else {
                ScrollView {
                    VStack(spacing: 32) {
                        // Header with Edit Interests Button
                        HStack {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Your Feed")
                                    .font(.system(size: 28, weight: .medium, design: .rounded))
                                    .foregroundColor(.primary)
                                
                                Text("Based on your interests")
                                    .font(.system(size: 16, design: .rounded))
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            Button(action: {
                                showingInterestsSheet = true
                            }) {
                                Image(systemName: "slider.horizontal.3")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.primary)
                                    .frame(width: 44, height: 44)
                                    .background(Color.white)
                                    .clipShape(Circle())
                                    .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 20)
                        .padding(.bottom, 10)
                        
                        // Interests Edit Sheet
                        .sheet(isPresented: $showingInterestsSheet) {
                            InterestsEditSheet(selectedInterests: $selectedInterests) {
                                // On Save
                                userData.interests = selectedInterests
                                Task {
                                    await regenerateMemes()
                                }
                            }
                        }
                        
                        // Meme Cards
                        ForEach(memeGenerator.memeItems) { item in
                            MemeCard(item: item)
                                .transition(.asymmetric(
                                    insertion: .scale.combined(with: .opacity),
                                    removal: .opacity
                                ))
                        }
                        
                        // Regenerate Button
                        Button(action: regenerateMemes) {
                            HStack {
                                Image(systemName: isRegenerating ? "arrow.triangle.2.circlepath" : "sparkles")
                                    .font(.system(size: 16, weight: .semibold))
                                    .rotationEffect(.degrees(isRegenerating ? 360 : 0))
                                
                                Text(isRegenerating ? "Generating..." : "Generate More")
                                    .font(.system(.headline, design: .rounded))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(isRegenerating ? Color.gray.opacity(0.3) : Color.black)
                            )
                            .shadow(color: isRegenerating ? .clear : .black.opacity(0.1),
                                    radius: 10, x: 0, y: 5)
                        }
                        .disabled(isRegenerating)
                        .padding(.horizontal)
                        .padding(.top, 10)
                        .padding(.bottom, 30)
                    }
                    .padding(.horizontal)
                }
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarHidden(true)
        .task {
            await generateMemes()
        }
    }
    
    private func generateMemes() async {
        isLoading = true
        let items = await memeGenerator.generateMemes(
            age: userData.age,
            interests: userData.interests
        )
        withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
            memeGenerator.memeItems = items
            isLoading = false
        }
    }
    
    private func regenerateMemes() {
        withAnimation {
            isRegenerating = true
        }
        
        Task {
            let items = await memeGenerator.generateMemes(
                age: userData.age,
                interests: userData.interests
            )
            
            withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                memeGenerator.memeItems = items
                isRegenerating = false
            }
        }
    }
}

struct LoadingView: View {
    @State private var rotation: Double = 0
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "square.stack.3d.up.fill")
                .font(.system(size: 40))
                .foregroundColor(.gray)
                .rotationEffect(.degrees(rotation))
                .onAppear {
                    withAnimation(.linear(duration: 2).repeatForever(autoreverses: false)) {
                        rotation = 360
                    }
                }
            
            Text("Generating Content")
                .font(.system(.headline, design: .rounded))
                .foregroundColor(.primary)
            
            Text("Just a moment...")
                .font(.system(.subheadline, design: .rounded))
                .foregroundColor(.secondary)
        }
    }
}

struct MemeCard: View {
    let item: MemeItem
    @State private var isExpanded = false
    @State private var imageScale: CGFloat = 1.0
    @State private var sharedImage: UIImage?
    @Environment(\.openURL) private var openURL
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Image
            AsyncImage(url: URL(string: item.imageUrl)) { phase in
                switch phase {
                case .empty:
                    Rectangle()
                        .fill(Color.gray.opacity(0.1))
                        .aspectRatio(16/9, contentMode: .fit)
                        .overlay(
                            ProgressView()
                                .tint(.gray)
                        )
                case .success(let image):
                    image
                        .resizable()
                        .aspectRatio(16/9, contentMode: .fit)
                        .scaleEffect(imageScale)
                        .onTapGesture {
                            withAnimation(.spring(response: 0.3)) {
                                imageScale = imageScale == 1.0 ? 1.02 : 1.0
                            }
                        }
                        .overlay(
                            Button(action: {
                                // Save the image for sharing
                                if let uiImage = image.asUIImage() {
                                    sharedImage = uiImage
                                    shareContent()
                                }
                            }) {
                                Image(systemName: "square.and.arrow.up")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.white)
                                    .frame(width: 44, height: 44)
                                    .background(Color.black.opacity(0.5))
                                    .clipShape(Circle())
                                    .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                            }
                            .padding(16),
                            alignment: .topTrailing
                        )
                case .failure:
                    Rectangle()
                        .fill(Color.gray.opacity(0.1))
                        .aspectRatio(16/9, contentMode: .fit)
                        .overlay(
                            Image(systemName: "photo")
                                .font(.system(size: 30))
                                .foregroundColor(.gray)
                        )
                @unknown default:
                    EmptyView()
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
            
            VStack(alignment: .leading, spacing: 12) {
                // Title and Author
                VStack(alignment: .leading, spacing: 8) {
                    Text(item.title)
                        .font(.system(.headline, design: .rounded))
                        .foregroundColor(.primary)
                    
                    HStack(spacing: 8) {
                        Image(systemName: "person.circle")
                            .foregroundColor(.gray)
                        
                        Text(item.authorName)
                            .font(.system(.subheadline, design: .rounded))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Button(action: {
                            if let url = URL(string: item.sourceUrl) {
                                openURL(url)
                            }
                        }) {
                            Image(systemName: "link")
                                .foregroundColor(.blue)
                                .frame(width: 32, height: 32)
                                .background(Color.blue.opacity(0.1))
                                .clipShape(Circle())
                        }
                        
                        Button(action: {
                            withAnimation(.spring(response: 0.3)) {
                                isExpanded.toggle()
                            }
                        }) {
                            Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                                .foregroundColor(.gray)
                                .frame(width: 32, height: 32)
                                .background(Color.black.opacity(0.05))
                                .clipShape(Circle())
                        }
                    }
                }
                
                // Description (shown when expanded)
                if isExpanded {
                    Text(item.text)
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.primary)
                        .padding(.top, 8)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .padding()
            .background(Color.white)
        }
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 5)
    }
}

extension MemeCard {
    func shareContent() {
        guard let image = sharedImage else { return }
        
        let shareText = """
        \(item.title)
        
        Uite ce am reușit să fac cu aplicația The Meme Times! Descarcă și încearcă și tu! 🎭
        """
        
        let activityViewController = UIActivityViewController(
            activityItems: [shareText, image],
            applicationActivities: nil
        )
        
        // Present the share sheet
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first,
           let rootViewController = window.rootViewController {
            rootViewController.present(activityViewController, animated: true)
        }
    }
}

#Preview {
    NavigationView {
        MemeGeneratorView(userData: UserData(name: "Test User", age: 25, interests: ["Memes 🎭", "Gaming 🎮"]))
    }
} 