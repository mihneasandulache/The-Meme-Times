import SwiftUI

struct InterestTag: View {
    let title: String
    let isSelected: Bool
    var showRemove: Bool = false
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(.system(.body, design: .rounded))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                
                if showRemove {
                    Image(systemName: "xmark")
                        .font(.caption2)
                        .foregroundColor(.red.opacity(0.8))
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isSelected ? Color.black : Color.white)
            )
            .foregroundColor(isSelected ? .white : .primary)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.black.opacity(isSelected ? 0 : 0.1), lineWidth: 1)
            )
            .shadow(color: isSelected ? .black.opacity(0.1) : .clear,
                    radius: 8, x: 0, y: 4)
        }
        .buttonStyle(ScaleButtonStyle())
    }
}

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .animation(.spring(response: 0.3), value: configuration.isPressed)
    }
}

#Preview {
    VStack(spacing: 20) {
        InterestTag(
            title: "Gaming 🎮",
            isSelected: true,
            action: {}
        )
        
        InterestTag(
            title: "Custom Interest",
            isSelected: true,
            showRemove: true,
            action: {}
        )
        
        InterestTag(
            title: "Unselected",
            isSelected: false,
            action: {}
        )
    }
    .padding()
} 