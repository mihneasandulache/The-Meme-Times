import SwiftUI

struct SuggestedInterestsSectionView: View {
    @Binding var selectedInterests: Set<String>
    let columns: [GridItem]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("SUGGESTED")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(UserDataModel.availableInterests, id: \.self) { interest in
                    InterestTag(
                        title: interest,
                        isSelected: selectedInterests.contains(interest)
                    ) {
                        withAnimation(.spring(response: 0.3)) {
                            if selectedInterests.contains(interest) {
                                selectedInterests.remove(interest)
                            } else {
                                selectedInterests.insert(interest)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

#Preview {
    SuggestedInterestsSectionView(
        selectedInterests: .constant(["Memes", "Gaming"]),
        columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
    )
} 