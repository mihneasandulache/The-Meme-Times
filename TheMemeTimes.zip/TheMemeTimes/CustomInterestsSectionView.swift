import SwiftUI

struct CustomInterestsSectionView: View {
    @Binding var selectedInterests: Set<String>
    let columns: [GridItem]
    
    var body: some View {
        if !selectedInterests.filter({ !UserDataModel.availableInterests.contains($0) }).isEmpty {
            VStack(alignment: .leading, spacing: 16) {
                Text("YOUR INTERESTS")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.secondary)
                    .tracking(1)
                    .padding(.horizontal)
                
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(Array(selectedInterests.filter { !UserDataModel.availableInterests.contains($0) }), id: \.self) { interest in
                        InterestTag(
                            title: interest,
                            isSelected: true,
                            showRemove: true
                        ) {
                            withAnimation(.spring(response: 0.3)) {
                                selectedInterests.remove(interest)
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

#Preview {
    CustomInterestsSectionView(
        selectedInterests: .constant(["Custom 1", "Custom 2"]),
        columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
    )
} 