import SwiftUI

struct InterestsInputView: View {
    @Binding var customInterest: String
    let addCustomInterest: () -> Void
    
    var body: some View {
        VStack(spacing: 16) {
            Text("INTERESTS")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
            
            HStack {
                TextField("Add custom interest", text: $customInterest)
                    .textFieldStyle(ModernTextFieldStyle())
                    .autocapitalization(.words)
                
                Button(action: addCustomInterest) {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(customInterest.isEmpty ? .gray : .black)
                        .frame(width: 36, height: 36)
                        .background(
                            Circle()
                                .fill(customInterest.isEmpty ? Color.black.opacity(0.05) : Color.white)
                        )
                }
                .disabled(customInterest.isEmpty)
            }
            .padding(.horizontal)
        }
    }
}

#Preview {
    InterestsInputView(customInterest: .constant(""), addCustomInterest: {})
} 