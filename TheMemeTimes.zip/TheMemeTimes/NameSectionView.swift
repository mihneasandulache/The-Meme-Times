import SwiftUI

struct NameSectionView: View {
    @Binding var name: String
    @Binding var isEditingName: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("NAME")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.secondary)
                .tracking(1)
                .padding(.horizontal)
            
            HStack {
                Text(name)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button(action: {
                    name = UserDataModel.funnyNames.randomElement() ?? "Meme Lord"
                }) {
                    Image(systemName: "dice")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.05))
                        .clipShape(Circle())
                }
                
                Button(action: { isEditingName.toggle() }) {
                    Image(systemName: "pencil")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.05))
                        .clipShape(Circle())
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.03), radius: 10, x: 0, y: 5)
            .padding(.horizontal)
        }
    }
}

#Preview {
    NameSectionView(name: .constant("Test User"), isEditingName: .constant(false))
} 